export const environment = {
production: false,
SUPABASE_URL: 'https://odszqwcthceqyijjhfrp.supabase.co',
SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9kc3pxd2N0aGNlcXlpampoZnJwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY3OTI3ODUsImV4cCI6MjA2MjM2ODc4NX0.rxLrWsJJDmq8vV2uLMaeDUsoRcOhWbvbKAugPan8LaE'
};
